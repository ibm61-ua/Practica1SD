package es.ua.sd.practica;

import java.net.SocketImpl;

public class CommonConstants {
	public static String REQUEST = "ev_request"; 
	public static String REQUEST_CP = "ev_requestcp";
	public static String TELEMETRY = "ev_telemetry"; 
	public static String CONTROL = "ev_control"; 
	public static String CENTRAL_STATUS = "ev_central_status"; 
	
}
